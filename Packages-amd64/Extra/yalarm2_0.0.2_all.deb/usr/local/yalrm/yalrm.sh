#!/bin/bash

export TEXTDOMAIN=yalrm
export OUTPUT_CHARSET=UTF-8
export VERSION='0.6.1'
export APP_DIR=/usr/local/yalrm
. gettext.sh

# create configuration directory if not exists
[ ! -d "$HOME/.yalrm" ] && mkdir -p "$HOME/.yalrm" && ln -sf $APP_DIR/themes/Clock/alarm_0.png $HOME/.yalrm && ln -sf $APP_DIR/themes/Clock/alarm.png $HOME/.yalrm
export CONF_DIR="$HOME/.yalrm"
# create preference file $HOME/.yalrm, if not exists
if [ ! -f "$CONF_DIR/prefs" ]; then
echo "PLAYER=\"aplay\"
sound=\"/usr/share/audio/2barks.wav\"
repeat=\"01\"
interval=\"00\"
dur=\"05\"
theme=\"Clock\"
frequency=\"1.00\"
rel=\"FALSE\"
relmin=\"1\"
relsec=\"0\"
postp=\"1\"" > $CONF_DIR/prefs
else
  if ! grep -q "rel=" $CONF_DIR/prefs; then  # v0.6.0
echo "rel=\"FALSE\"
relmin=\"1\"
relsec=\"0\"" >> $CONF_DIR/prefs
  fi
    if ! grep -q "postp=" $CONF_DIR/prefs; then  # v0.6.1
    echo "postp=\"1\"" >> $CONF_DIR/prefs
    fi
fi

#themes
##list directories
THEMES=$(echo `ls $APP_DIR/themes` | sed 's/ /:/g')
##current theme config file
[ -f "$CONF_DIR/colors" ] || ln -sf "$APP_DIR/themes/Clock/colors" $CONF_DIR
##current theme background file
[ -f "$CONF_DIR/bg.jpg" ] || ln -sf "$APP_DIR/themes/Clock/bg.jpg" $CONF_DIR
.  $CONF_DIR/colors

#create gtkrc yalrm file if not existing
echo "style \"yalrm_clock\" { font_name=\"TickingTimebombBB 26\" base[NORMAL]=\"#$base\" text[NORMAL]=\"#$text\" }
	widget \"*\" style \"yalrm_clock\"
pixmap_path \"/root/.yalrm\"
style \"windowStyle\" {
    engine \"pixmap\" {
    image
      {
          function        = FLAT_BOX
          file            = \"bg.jpg\"
          border          = { 0, 0, 0, 0 }
          stretch         = FALSE
      }
  }
}
widget_class \"<GtkWindow>\" style \"windowStyle\"" > /tmp/gtkrc_yalrm

about () {
yad --window-icon="gtk-about" --width="550" --image="/usr/share/icons/hicolor/48x48/apps/yalrm.png" --center --title="$(gettext 'About')" --form --entry --entry-label="<b>$(gettext 'Web page:')</b>" --entry-text="http://murga-linux.com/puppy/viewtopic.php?t=97458&start=757" --text="\n\t<b><span size='large'>Yalrm v$VERSION - $(gettext 'Alarm Sheduler')</span></b>\n\n\t\t$(gettext 'fredx181 <i>(inspired by misko_2083)</i>\n\t\tArgolance <i>(cosmetics, icons and layout)')</i>\n\t\t<span size='small'>$(gettext 'December 2019')</span>\t\n" --button="gtk-close:0"
}; export -f about

alarm_info () {
. gettext.sh
TXT="- <b>$(gettext 'Duration</b> is how long an audio file will be played.
For example: an audio file that has duration 4 minutes,
and you want only the first 10 seconds to be played, then set duration to 10.

- <b>Interval</b> is the duration between repeating the alarm.
<i>(except when Duration time is higher than Interval, see below)</i>
For example: when the alarm starts at 10:00:00, and the interval is 10,
then it will be repeated at 10:00:10, 10:00:20, 10:00:30 etc...

- <b>Repeat</b> is the amount of times the alarm will be played.

- <b>Postpone</b> is the amount of minutes the alarm will be postponed (once running).
(right-click menu "Postpone Alarm" from tray-icon)

<i><b>Notes</b>:
	When the Duration time is higher than Interval time,
	then Duration time will be the time between repeating the alarm.

	When Duration value is lower than Interval there will be silence between repeating.
	For example: Duration is 10 seconds and Interval is 20 seconds,
	then there will be 10 seconds silence, everytime before the alarm is repeated.')</i>"  
yad --window-icon="gtk-info" --title="$(gettext 'Information about Duration, Interval, Repeat and Postpone')" --text="$TXT" --borders=10 --width 630 --center --button="gtk-close:0"
}; export -f alarm_info 
	
alrm () {
export PLAYER="$2"
if [ -z "$PLAYER" ]; then
yad --skip-taskbar --center --undecorated --image="/usr/local/lib/X11/pixmaps/error.png" --text="\n\t$(gettext 'No player selected!')\t\t" --button="gtk-close:0"
exit
fi
sed -i 's#^PLAYER=.*#PLAYER="'"$PLAYER"'"#' $CONF_DIR/prefs

theme="$4"
ln -sf "$APP_DIR/themes/$theme/alarm_0.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_1.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_2.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_3.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_4.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_5.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_6.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_cancel.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/alarm_quit.png" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/bg.jpg" $CONF_DIR
ln -sf "$APP_DIR/themes/$theme/colors" $CONF_DIR

sed -i 's#^theme=.*#theme="'"$theme"'"#' $CONF_DIR/prefs

export sound="$1"
if [ ! -f "$sound" ]; then
yad --skip-taskbar --center --undecorated --image="/usr/local/lib/X11/pixmaps/error.png" --text="\n\t$(gettext 'No sound file selected!')\t\t" --button="gtk-close:0"
exit
fi
sed -i 's#^sound=.*#sound="'"$sound"'"#' $CONF_DIR/prefs

rel="$3"
sed -i 's#^rel=.*#rel="'"$rel"'"#' $CONF_DIR/prefs

frequency="$8"
sed -i 's#^frequency=.*#frequency="'"$frequency"'"#' $CONF_DIR/prefs

export hr="$5"
[ "${hr:0:1}" = '0' ] && hr=${hr#?}
export mn="$9"

export repeat="$6"
sed -i 's#^repeat=.*#repeat="'"$repeat"'"#' $CONF_DIR/prefs

export interval="${10}"
sed -i 's#^interval=.*#interval="'"$interval"'"#' $CONF_DIR/prefs

relmin="$7"
sed -i 's#^relmin=.*#relmin="'"$relmin"'"#' $CONF_DIR/prefs

relsec="${11}"
sed -i 's#^relsec=.*#relsec="'"$relsec"'"#' $CONF_DIR/prefs

export dur="${12}"
sed -i 's#^dur=.*#dur="'"$dur"'"#' $CONF_DIR/prefs

    if [ "$rel" = "FALSE" ]; then
target="$hr:$mn"
export targetn="$hr:$mn"
export targetv="$hr:$mn"
    else
target=$relmin
export targetn="$(date +"%H:%M:%S") + ${relmin} min $relsec sec."
export targetv="$(date +"%H:%M")+${relmin}:${relsec}"
    fi

export postp="${13}"
sed -i 's#^postp=.*#postp="'"$postp"'"#' $CONF_DIR/prefs

command () {
. gettext.sh
#yad --undecorated --image=$B_ICON --borders 12 --title="Alarm" --text="    \t<b>Alarm set to $hr:$mn</b> " --geometry=280x50-40-50 --no-buttons --timeout 4
gtk-splash -placement top -bg grey90 -icon "$CONF_DIR/alarm_0.png" -timeout 4 -text "<b>$(eval_gettext 'Alarm set to $targetn')</b>"
} ; export -f command

command_running () {
. gettext.sh
#yad --undecorated --image=$F_ICON --borders 12 --title="Alarm" --text="    \t<b>Alarm $hr:$mn running...</b> \n To cancel, right-click icon for menu" --geometry=280x50-40-50 --no-buttons --timeout 4
if [ -f /tmp/paused_running.$targetv ]; then
gtk-splash -placement top -bg grey90 -icon "$CONF_DIR/alarm_0.png" -timeout 4 -text " <b>$(eval_gettext 'Alarm running...</b>
 Right-click: <i>Menu')</i>"
elif [ -f /tmp/paused.$targetv ]; then
gtk-splash -placement top -bg grey90 -icon "$CONF_DIR/alarm_0.png" -timeout 4 -text " <b>$(eval_gettext 'Alarm postponed for '$1' minutes</b>
 Right-click: <i>Menu')</i>"
else
gtk-splash -placement top -bg grey90 -icon "$CONF_DIR/alarm_0.png" -timeout 4 -text " <b>$(eval_gettext 'Alarm $targetn running...</b>
 Right-click: <i>Menu')</i>"
fi
} ; export -f command_running

cancel_quit_tray () {
#apid=$(ps -eo pid,cmd | grep "^$1" | sed -n 's/.* Set to \([^ ]*\).*/\1/p')
### change apid variable
apid="$2"
echo [$apid]
kill $1
kill $(cat /tmp/yalrm_apid.$apid 2> /dev/null)
rm -f /tmp/yalrm_apid.$apid
rm -f $PIPE2
gtk-splash -placement top -bg grey90 -icon "$CONF_DIR/alarm_cancel.png" -timeout 2 -text " $(gettext 'Scheduled Alarm cancelled!')"
}; export -f cancel_quit_tray

quit_tray () {
kill $1
rm -f $PIPE2
gtk-splash -placement top -bg grey90 -icon "$CONF_DIR/alarm_quit.png" -timeout 2 -text " $(gettext 'Scheduled Alarm running in the background
 Systray exited!')"
}; export -f quit_tray

quit_tray_running () {    #### changed for pause options
kill $(cat /tmp/pidplayer.$targetv 2> /dev/null) 2> /dev/null
kill $PLPID 2> /dev/null
[ -f /tmp/paused.$targetv ] && kill $(cat /tmp/paused.$targetv 2> /dev/null)
kill $1 2> /dev/null
echo "quit" >$PIPE
export YPID=$1
rm -f /tmp/paused.$targetv
rm -f /tmp/paused_running.$targetv
rm -f $PIPE
}; export -f quit_tray_running

#### add function tray_running_pause
tray_running_pause () {
. gettext.sh
touch /tmp/paused.$targetv
echo menu:"$(gettext 'Stop Alarm and Exit tray')!bash -c 'quit_tray_running'!gtk-quit" >$PIPE &

export SLPMIN=$(($2 / 60))

echo tooltip:"$(gettext 'Alarm postponed for '$SLPMIN' minutes')" >$PIPE &
echo action:'bash -c "command_running '$SLPMIN'"' >$PIPE &
command_running $SLPMIN &
export PPIPE=$1
(
kill $(cat /tmp/pidplayer.$targetv 2> /dev/null) 2> /dev/null
kill $PLPID
sleep $2

touch /tmp/paused_running.$targetv
command_running &
echo tooltip:"$(gettext 'Alarm running...')" >$PIPE &

check_pidplayer () {
pidplayer=$(ps -eo pid,cmd | grep -v grep | grep -v "/bin/bash" | grep -w "$PLAYER $sound" | awk '{ print $1 }')
}
    if [ $repeat = 0 ]; then
while true; do
$PLAYER "$sound" </dev/null >/dev/null 2>&1 &
check_pidplayer
while true; do
#[ -n "$pidplayer" ] && break
check_pidplayer
if [ -n "$pidplayer" ]; then
echo $pidplayer > /tmp/pidplayer.$targetv
break
fi
sleep 0.2
done
sleep $dur
[ -n "$pidplayer" ] && kill -9 $pidplayer
  if [ $dur -lt $interval ]; then
  sleep $(($interval-$dur)) 2> /dev/null
#  else
#  sleep $interval 2> /dev/null
  fi
done
    else
while [ $repeat -gt 0 ]; do
$PLAYER "$sound" </dev/null >/dev/null 2>&1 &
check_pidplayer
while true; do
#[ -n "$pidplayer" ] && break
check_pidplayer
if [ -n "$pidplayer" ]; then
echo $pidplayer > /tmp/pidplayer.$targetv
break
fi
sleep 0.2
done
sleep $dur
[ -n "$pidplayer" ] && kill -9 $pidplayer
repeat=$(($repeat-1))
if [ $repeat -gt 0 ]; then
  if [ $dur -lt $interval ]; then
  sleep $(($interval-$dur)) 2> /dev/null
#  else
#  sleep $interval 2> /dev/null
  fi
fi
done
    fi

) &
export PLPID=$!
echo $PLPID > /tmp/paused.$targetv
wait $PLPID
echo -e "quit" >${PPIPE}
rm -f /tmp/paused.$targetv
rm -f /tmp/pidplayer.$targetv
rm -f /tmp/paused_running.$targetv
#rm -f $PIPE
}; export -f tray_running_pause

#### added $PIPE (for activated alarm tray icon)
export PIPE="/tmp/Y_ALRM.$RANDOM"
mkfifo $PIPE

# attach a file descriptor to the file
exec 3<> $PIPE
#### end added

export PIPE2="/tmp/Y_ALRM2.$RANDOM"
mkfifo $PIPE2

# attach a file descriptor to the file
exec 4<> $PIPE2

show_icon () {
. gettext.sh    #### required ?
while true; do
   echo 'icon:'$CONF_DIR/alarm_1.png;
   sleep $frequency;
   echo 'icon:'$CONF_DIR/alarm_2.png;
   sleep $frequency;
   echo 'icon:'$CONF_DIR/alarm_3.png;
   sleep $frequency;
   echo 'icon:'$CONF_DIR/alarm_2.png;
   sleep $frequency;
[ ! -f /tmp/yalrm_apid.$targetv ] && break
done >$PIPE2 &

yad \
--icon-size=24 \
--notification \
--image="$CONF_DIR/alarm_1.png" \
--auto-kill \
--no-middle \
--listen \
--text=" $(eval_gettext 'Alarm scheduled for <b>$targetv</b> running in the background...
 Right-click: <i>Menu')</i>" \
--command="bash -c command" <&4 &
export XPID=$!
### change to: cancel_quit_tray $XPID $targetv
echo menu:"$(gettext 'About')!bash -c 'about'!gtk-about||$(gettext 'Info')!bash -c 'alarm_info'!gtk-info||$(gettext 'Cancel Alarm')!bash -c 'cancel_quit_tray $XPID $targetv'!gtk-cancel|$(gettext 'Remove from the tray only')!bash -c 'quit_tray $XPID'!gtk-clear" >$PIPE2 &
}; export -f show_icon

hrnow=$(echo $(date +"%k"))

(
    if [ "$rel" = "FALSE" ]; then
# For when trying to set alarm for next day e.g. from current 21:00 to target 6:00
if [ "$hr" -eq "$hrnow" ] &&  [ "$mn" -le "$(date +"%M")" ]; then
# prompt yes/no in case accidentally chosen current hour but less than current minute
yad --center --title="Are you sure?" --text="  Are you sure to set the alarm to $target (next day) ?" --width=400 --button="Yes:0"  --button="No:1"
[ $? -ne 0 ] && exit
command & show_icon
sleep $(( $(date --date="$(((23+$hr) - $hrnow)):$mn" +%s) - $(date --date="00:$(date +"%M"):$(date +"%S")" +%s) + 3600 ))
elif [ "$hr" -lt "$hrnow" ]; then
command & show_icon
sleep $(( $(date --date="$(((24+$hr) - $hrnow)):$mn" +%s) - $(date --date="00:$(date +"%M"):$(date +"%S")" +%s) ))
else
command & show_icon
sleep $(( $(date --date="$target" +%s) - $(date +%s) ));
fi
    else
    command & show_icon
    sleep $(( $(($relmin * 60)) + $relsec ))
    fi

kill $XPID
rm -f $PIPE2
echo "$(gettext 'Wake Up!')"

command_running &

(
check_pidplayer () {
pidplayer=$(ps -eo pid,cmd | grep -v grep | grep -v "/bin/bash" | grep -w "$PLAYER $sound" | awk '{ print $1 }')
}
    if [ $repeat = 0 ]; then
while true; do
$PLAYER "$sound" </dev/null >/dev/null 2>&1 &
check_pidplayer
while true; do
#[ -n "$pidplayer" ] && break
check_pidplayer
if [ -n "$pidplayer" ]; then
echo $pidplayer > /tmp/pidplayer.$targetv
break
fi
sleep 0.2
done
sleep $dur
[ -n "$pidplayer" ] && kill -9 $pidplayer
  if [ $dur -lt $interval ]; then
  sleep $(($interval-$dur)) 2> /dev/null
#  else
#  sleep $interval 2> /dev/null
  fi
done
    else
while [ $repeat -gt 0 ]; do
$PLAYER "$sound" </dev/null >/dev/null 2>&1 &
check_pidplayer
while true; do
#[ -n "$pidplayer" ] && break
check_pidplayer
if [ -n "$pidplayer" ]; then
echo $pidplayer > /tmp/pidplayer.$targetv
break
fi
sleep 0.2
done
sleep $dur
[ -n "$pidplayer" ] && kill -9 $pidplayer
repeat=$(($repeat-1))
if [ $repeat -gt 0 ]; then
  if [ $dur -lt $interval ]; then
  sleep $(($interval-$dur)) 2> /dev/null
#  else
#  sleep $interval 2> /dev/null
  fi
fi
done
    fi
) &
export PLPID=$!

#### change menu for pause options and using $PIPE for tray icon
#echo menu:"$(gettext 'Stop Alarm and Exit tray')!bash -c quit_tray_running!gtk-quit"
while true; do
   echo 'icon:'$CONF_DIR/alarm_4.png;
   sleep $frequency;
   echo 'icon:'$CONF_DIR/alarm_5.png;
   sleep $frequency;
   echo 'icon:'$CONF_DIR/alarm_6.png;
   sleep $frequency;
   echo 'icon:'$CONF_DIR/alarm_5.png;
   sleep $frequency;
[ ! -f /tmp/yalrm_apid.$targetv ] && break
done >$PIPE &
slp=$(($postp * 60))
slp1=120
slp2=300
slp3=600
slp4=900
slp5=1200
slp6=1800
echo menu:"$(gettext 'Stop Alarm and Exit tray')!bash -c 'quit_tray_running $YPID $PLPID'!gtk-stop|$(gettext 'Postpone Alarm (preset) by '$postp' min')!bash -c 'tray_running_pause $PIPE $slp'!$APP_DIR/postpone.png|$(gettext 'Postpone by 2 min')!bash -c 'tray_running_pause $PIPE $slp1'!$APP_DIR/postpone.png|$(gettext 'Postpone by 5 min')!bash -c 'tray_running_pause $PIPE $slp2'!$APP_DIR/postpone.png|$(gettext 'Postpone by 10 min')!bash -c 'tray_running_pause $PIPE $slp3'!$APP_DIR/postpone.png|$(gettext 'Postpone by 15 min')!bash -c 'tray_running_pause $PIPE $slp4'!$APP_DIR/postpone.png|$(gettext 'Postpone by 20 min')!bash -c 'tray_running_pause $PIPE $slp5'!$APP_DIR/postpone.png|$(gettext 'Postpone by 30 min')!bash -c 'tray_running_pause $PIPE $slp6'!$APP_DIR/postpone.png" >$PIPE &
yad --icon-size=24 --notification \
--no-middle \
--image=$CONF_DIR/alarm_1.png \
--listen \
--text="$(eval_gettext 'Alarm sheduled for $targetn running...')" \
--command="bash -c command_running" <&3 &
#### end change

export YPID=$!
wait $PLPID

#### look for existing file /tmp/paused.$targetv
while true; do
[ ! -f /tmp/paused.$targetv ] && break
sleep 1
done
[ ! -f /tmp/paused.$targetv ] && kill $YPID 2> /dev/null
#kill $YPID
#rm -f $PIPE
#### end change

) &
export ALPID=$!
echo $ALPID > /tmp/yalrm_apid.$targetv

wait $ALPID
kill $XPID 2> /dev/null
#### added for pause options
[ ! -f /tmp/paused.$targetv ] && echo "quit" >$PIPE
rm -f $PIPE
rm -f $PIPE2
rm -f /tmp/yalrm_apid.$targetv
rm -f /tmp/paused.$targetv
rm -f /tmp/pidplayer.$targetv
rm -f /tmp/paused_running.$targetv
}; export -f alrm

# set hour and minute at current time in yad GUI
hour=$(echo -e "$(seq -w $(date +"%H") 23)\n$(seq -w 00 $(date +"%H"))" | sed '$ d' |xargs | tr ' ' ':')
min=$(echo -e "$(seq -w $(date +"%M") 59)\n$(seq -w 00 $(date +"%M"))" | sed '$ d' |xargs|tr ' ' ':')

. $CONF_DIR/prefs

while :
do 
  date +"   %H":"%M":"%S"    #### added more spaces , to fit in the middle
pidyad="$(pgrep -lf "yad --plug=$$" | awk '{ print $1 }')"
[ -z "$pidyad" ] && break
#### change to sleep 0.5 (two fields to cycle through)
  sleep 0.5
done | GTK2_RC_FILES=/tmp/gtkrc_yalrm yad --plug="$$" --borders=8 --tabnum=1 --form --cycle-read --columns=2 --field="\t\t\t   : " --field='\t\t\t':lbl &

yad --plug="$$" --tabnum=2 --form --columns=4 --item-separator=":" \
--text="\t<b><span size='large'>$(gettext 'Alarm Scheduler</span></b>\n\tAdjusting settings:')" \
--field="$(gettext 'Sound')::sfl" "$sound" \
--field="$(gettext 'Player')::sfl" "$PLAYER" \
--field="$(gettext 'Set alarm after minutes/seconds =>:')chk" "$rel" \
--field="$(gettext 'Icon theme')::CB" "$theme:""$THEMES" \
--field="<b>$(gettext 'Hour')</b>::CB" "$hour" \
--field="$(gettext 'Repeat:\n<i><span size="small">(0=infinite)</span></i>'):NUM" "$repeat:00..300:01" \
--field="$(gettext 'Minutes:'):NUM" "$relmin:00..10000:01" \
--field="$(gettext 'Frequency:\n<i><span size="small">(seconds)</span></i>'):CB" "$frequency:0.10:0.25:0.50:0.75:1.00:1.50:2.00" \
--field="<b>$(gettext 'Minutes')</b>::CB" "$min" \
--field="$(gettext 'Interval:\n<i><span size="small">(seconds)</span></i>'):NUM" "$interval:00..1000:01" \
--field="Seconds::NUM" "$relsec:00..59:01" \
--field="$(gettext 'Information'):gtk-info: <b>$(gettext 'Information')</b> :fbtn" "bash -c alarm_info" \
--field="$(gettext 'Duration:\n<i><span size="small">(seconds)</span></i>'):NUM" "$dur:01..10000:01" \
--field="$(gettext 'Postpone:\n<i><span size="small">(minutes)</span></i>'):NUM" "$postp:01..1000:01" \
--field=" :lbl" "" \
--field=":$CONF_DIR/alarm.png: <b>$(gettext 'Set Alarm</b> <i>(press the escape key to quit)')</i> :BTN" 'bash -c "alrm %1 %2 %3 %4 %5 %6 %7 %8 %9 %10 %11 %12 %13 %14 %15 %16"' &
yad --window-icon=/usr/share/icons/hicolor/48x48/apps/yalrm.png --center --borders=8 --title="Yalrm v$VERSION" --paned --key="$$" --orient=vert --no-buttons
