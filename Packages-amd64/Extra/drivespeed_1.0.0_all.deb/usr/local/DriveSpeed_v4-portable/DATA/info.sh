#!/bin/sh
#
# Infobox for DriveSpeed. © Mike Walsh - May 2021.
#
HERE="$(dirname "$(readlink -f "$0")")"
#
yad --center --window-icon=$HERE/ICONS/drivespeed-icon.png --title="    DriveSpeed - Info" --form --width=600 --text=" Info for DriveSpeed speed tester
--------------------------------------
This is a fairly basic, 'dd'-based speed tester utility,
which can be used to test ANY drive.....HDD, SSD. USB flash,
SD card, zip drive. whatever. If 'dd' can write to it, DriveSpeed
can test it.

In the case of the 'portable', clicking on the DriveSpeed script brings up the GUI. For the .pet, it launches from the MenuEntry
under 'Utility'.
---------------------------------------------------------------------- 
 The script checks for all available partitions on your system. Select the partition you wish to run the test from; this is where the 'testfile' will be written. Now click on Mount. After this, select the block size you wish to run the test with, by clicking on the appropriate button. In normal operation, the write operation is tested first, since this creates the test file. Once this has been created, you can then test the read speed.
 
 (You can't run the 'read' test BEFORE the 'write', since you won't have a file to work with. If you try to, a pop-up will remind you of this...)

In all cases, the utility will write 1 GB of data to a file called 
*testfile* - at the same time, giving a real-time readout of the speeds achieved in a 'progress' window. Since DriveSpeed allows the user to select the desired block size, you can run both read and write operations with different block sizes if you so wish.
-------------------------------------------------------------------
PLEASE REMEMBER - Clear the cache buffers between operations,
as this helps to keep each operation clean, and starting from the same nominal condition each time.
-----------------------------------------------------------------
Hope some of you may find it useful.
                                                                " --button="Close:0" && exit
