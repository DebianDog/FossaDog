You can put here binaries (and libs they may need), e.g. poweriso, unrar, ccrypt, 
veracrypt, etc. and UExtract will be able to use them from within this location.
