#!/bin/sh
#Based on scripts from trapster March 2009 for Puppy 4.00, GPL 
#Modified by afishe2000 July 2010
#Modified March 17 20012 bigbass

  DIR=/usr/share/applications
  ls $DIR > /usr/local/desktop_view_edit/lists/included_menu_items.txt
  sed -i 's/\.desktop//g' /usr/local/desktop_view_edit/lists/included_menu_items.txt
  
  
exit
